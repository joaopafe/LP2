﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            Double a, b, c;


            if (Double.TryParse(txtA.Text, out a) && Double.TryParse(txtB.Text, out b) && Double.TryParse(txtC.Text, out c))
            {
                if (a > 0 && b > 0 && c > 0)
                {
                    if ((Math.Abs(a - b) < c && c < (a + b)) && (Math.Abs(a - c) < b && b < (a + c)) && (Math.Abs(b - c) < a && a < (b + c)))
                    {
                        if (a != b && a != c && c != b)
                        {
                            txtResultado.Text = "Triangulo Escaleno";
                        }
                        else if (a == b || a == c || c == b)
                        {
                            txtResultado.Text = "Triangulo Isosceles";
                        }
                        else if (a == b && a == c && b == c)
                        {
                            txtResultado.Text = "Triangulo Equilatero";
                        }
                    }
                }
                else
                {
                    txtResultado.Text = "Favor digitar somente valores positivos";
                }
            }
            else
            {
                MessageBox.Show("Por favor, preencha todos os campos");
            }
        }
    }
}
