﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Double peso, altura, imc;


            if (Double.TryParse(txtAltura.Text, out altura) && Double.TryParse(txtPeso.Text, out peso))
            {
                if (altura>0 || peso>0)
                {
                    imc = peso / Math.Pow(altura, 2);
                    txtIMC.Text = imc.ToString();
                }
                else
                {
                    MessageBox.Show("Por favor, digite apenas número maiores do que 0");
                }
            }
            else
            {
                MessageBox.Show("Por favor, digite apenas números");
            }

            if (Convert.ToDouble(txtIMC) < 18.5)
            {
                txtResultado.Text = "Abaixo do peso";
            }
            else if (Convert.ToDouble(txtIMC) < 24.9)
            {
                txtResultado.Text = "Peso normal";
            }
            else if (Convert.ToDouble(txtIMC) < 29.9)
            {
                txtResultado.Text = "Sobrepeso";
            }
            else if (Convert.ToDouble(txtIMC) < 34.9)
            {
                txtResultado.Text = "Obesidade grau I";
            }
            else if (Convert.ToDouble(txtIMC) < 39.9)
            {
                txtResultado.Text = "Obesidade grau II";
            }
            else
            {
                txtResultado.Text = "Obesidade grau III";
            }
        }

        private void txtResultado_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtIMC.Text = "";
            txtResultado.Text = "";
        }
    }
}
