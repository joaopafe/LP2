namespace PCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtValor3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtValor1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            double valor1, valor2, resultado;
            if (Double.TryParse(txtValor1.Text, out valor1) && Double.TryParse(txtValor2.Text, out valor2))
            {
                resultado = valor1 + valor2;
                txtValor3.Text = resultado.ToString();
            }                
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            double valor1, valor2, resultado;
            if (Double.TryParse(txtValor1.Text, out valor1) && Double.TryParse(txtValor2.Text, out valor2))
            {
                resultado = valor1 - valor2;
                txtValor3.Text = resultado.ToString();
            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            double valor1, valor2, resultado;
            if (Double.TryParse(txtValor1.Text, out valor1) && Double.TryParse(txtValor2.Text, out valor2))
            {
                resultado = valor1 * valor2;
                txtValor3.Text = resultado.ToString();
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            double valor1, valor2, resultado;
            if (Double.TryParse(txtValor1.Text, out valor1) && Double.TryParse(txtValor2.Text, out valor2))
            {
                if (valor2 == 0)
                {
                    txtValor3.Text = "Resultado Inv�lido";
                }
                else
                {
                    resultado = valor1 / valor2;
                    txtValor3.Text = resultado.ToString();
                }
            }
        }

        private void txtValor2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValor1.Text = "";
            txtValor2.Text = "";
            txtValor3.Text = "";
        }
    }
}